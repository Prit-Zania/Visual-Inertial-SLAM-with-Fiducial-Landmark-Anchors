# OnePlus 12R: MSCKF + IMU + natural visual features + ArUco

This is a separate source project. It records data on an Android phone and estimates pose and a marker map on a laptop. It does **not** contain a new APK. Android SDK licenses were not accepted and an Android build was not run, in accordance with the requested source-only scope.

## Start here

On this computer the Python environment is already installed inside `.venv`. Run:

```powershell
.\Start-Dashboard.ps1
```

To reproduce setup on another computer with Python 3.12:

```powershell
.\Setup-Python.ps1
.\Start-Dashboard.ps1
```

The dashboard can start the Wi-Fi receiver, import a phone recording, process a dataset, run the no-ArUco baseline, load results, inspect sensor health and uncertainty, and evaluate a surveyed trajectory. Pose estimation and map optimization run **after recording**. Live acquisition provides camera preview, marker IDs returned by the laptop, and capture/IMU status; this version does not stream a live MSCKF pose back to the phone.

To try the complete laptop workflow without a phone:

```powershell
.\Run-Demo.ps1
```

This creates synthetic images, timestamps, IMU measurements, known marker poses and ground truth under `demo_output/synthetic`, processes them, and compares against a baseline. The generated experiment includes a marker-hidden section. It is a software regression example, **not measured phone performance**. In the dashboard, select `demo_output/synthetic/processed` using **Load results**.

## What is implemented

| Part | Actual implementation |
|---|---|
| Phone sensing | Native Java Camera2 and SensorManager; image capture timestamps; raw accelerometer, gyro, compass and all accessible continuous/on-change sensors; per-sensor accuracy and inventory |
| Phone resilience | Asynchronous local JSONL log plus a separate bounded Wi-Fi queue; explicit dropped-record counts; local file can recover Wi-Fi losses |
| Core estimator | 15-dimensional error state: orientation, position, velocity, gyro bias and accel bias; camera pose cloning with cross-covariances; MSCKF feature updates |
| Natural features | KLT tracking, forward/backward check, RANSAC rejection, triangulation, low-parallax rejection, nullspace elimination of feature states, chi-square gating |
| ArUco | Subpixel corners, IPPE/PnP validation, corner-reprojection Kalman updates, correlated unknown-marker states, fixed surveyed anchors, map save/reload |
| World reference | First observed marker defines the local origin; a supplied map places the estimate in its existing frame |
| Compass | Optional calibrated magnetic heading update with field-magnitude, Android accuracy and innovation checks; disabled until a reference field is supplied |
| Failure handling | Stale/invalid sample checks; gyro-only rotation when acceleration is unavailable; camera/marker fallback; uncertainty growth; degraded/lost states; checked fixed-anchor relocalization |
| Mapping | Independent fixed-window optimization of navigation states, feature points and markers with IMU preintegration; global pose graph with marker revisits and verified visual loops |
| Confidence | Pose and marker covariance, measurement NIS, residuals, active measurements, sensor health and tracking validity saved to disk |
| Depth/Laser AF | Camera capability and range-related key inventory; optional DEPTH16 recording; calibrated registered marker depth update only when explicitly enabled |
| IR | Emitter capability detection; no invented distance measurements |

This is an original educational MSCKF implementation using NumPy/SciPy/OpenCV. It does **not** wrap OpenVINS or claim OpenVINS validation. There is **no particle filter / Rao–Blackwellized particle filter** in this project. See [DESIGN.md](docs/DESIGN.md) for equations, assumptions and limitations.

## Android source and later build

The Android project is in `android/`. Application ID: `org.oneplus.slam`.

Prerequisites for a later build, when the Android SDK terms have been accepted by the user:

- JDK 17, Gradle 8.9, Android SDK platform 35 and the build tools required by Android Gradle Plugin 8.7.3.
- Open `android/` in Android Studio, or use an installed Gradle 8.9 distribution.
- Set the SDK path in Android Studio or in `android/local.properties` (`sdk.dir=...`).
- From `android/`, run `gradle assembleDebug`. Expected output: `app/build/outputs/apk/debug/app-debug.apk`.

No Gradle wrapper binary or SDK is bundled. No script accepts licenses automatically. Java syntax was checked, but **Android API compilation, installation, camera operation and device performance remain unverified**.

Once built, install the APK, grant camera permission, keep the app visible, and record. Capture stops and saves when the app leaves the foreground. Background screen-off recording is not implemented.

## Record a real run

1. Put phone and laptop on the same trusted Wi-Fi network. Start the receiver in the dashboard. Enter the laptop IPv4 address, port and pairing token on the phone. The token provides pairing, not transport encryption.
2. Start capture and hold the phone still for at least two seconds. Then move slowly with visible room texture and printed markers.
3. Stop capture. The laptop dataset appears under `recordings/`. Select that folder in the dashboard.
4. If Wi-Fi failed, retrieve the phone's `Android/data/org.oneplus.slam/files/sessions/<session-id>/capture.jsonl` using USB/ADB and use **Import phone file**. Keep the file within this project's `recordings/` folder if you want all project data together.
5. Use a measured calibration file, then process. The example phone calibration contains placeholder values and is intentionally blocked by default.

CLI equivalents:

```powershell
.\.venv\Scripts\python.exe -m slam.receiver --port 8765 --output recordings
.\.venv\Scripts\python.exe -m slam.cli import recordings\capture.jsonl --output recordings
.\.venv\Scripts\python.exe -m slam.cli process recordings\YOUR_RUN --config config\calibrated.json
.\.venv\Scripts\python.exe -m slam.cli process recordings\YOUR_RUN --config config\calibrated.json --map recordings\EARLIER_RUN\processed\marker_map.json
.\.venv\Scripts\python.exe -m slam.cli process recordings\YOUR_RUN --config config\calibrated.json --baseline --no-smooth
```

An exploratory `--allow-uncalibrated` option exists for debugging. Its results must not be presented as calibrated measurements.

## Calibration

Camera calibration from a recorded chessboard sequence:

```powershell
.\.venv\Scripts\python.exe -m slam.calibrate camera recordings\CALIBRATION_RUN --columns 9 --rows 6 --square-m 0.025 --output config\camera.json
```

Use at least 12 views covering different image locations, tilts and distances. `columns` and `rows` are **inner corners**, and the square width must be measured.

Fit camera-to-IMU rotation and residual clock offset from a fixed marker sequence while rotating around several axes:

```powershell
.\.venv\Scripts\python.exe -m slam.calibrate rotation-time recordings\ROTATION_RUN --config config\camera.json --marker-id 0 --output config\calibrated.json
```

This command checks rotational excitation, fits rotation/time/gyro bias, and writes a diagnostic report. It does **not** identify camera–IMU translation. Measure that translation or use a full calibration package such as Kalibr. Record the measured transform and verify a separate sequence before setting `calibration_verified: true`. See [CALIBRATION.md](docs/CALIBRATION.md).

For a camera reporting Android `REALTIME` timestamps, sensor and image timestamps are in the elapsed-realtime clock domain. An `UNKNOWN` timestamp source is blocked unless `camera_clock_offset_verified` is explicitly set after measuring the clock relationship. There is no laptop-arrival-time substitution.

## Markers and coordinates

```powershell
.\.venv\Scripts\python.exe -m slam.markers --output markers --count 8 --size-mm 120
```

The supplied SVG sheets are A4. Print at **100% scale**, measure the black square, and put its width in `marker_size_m`. Use fixed, unique `DICT_6X6_250` IDs. Place roughly 6–10 markers around the room.

All `T_A_B` transforms map a point expressed in B into A. `T_body_camera` maps optical camera coordinates (x right, y down, z forward) into Android sensor coordinates. A loaded map must use the same marker size, dictionary and conventions. Saved learned-marker covariance is retained on map reload; surveyed anchors may be fixed.

## Raw sensor API and visualization

Run `Start-Sensor-API.ps1`, then open `http://127.0.0.1:8080` in a browser. The page lists every sensor exposed by Android, including wake-up mode, reporting mode, registration result, sample count, effective rate and accuracy. Select a sensor to plot every recorded value component or export it as CSV.

Read-only JSON endpoints:

- `GET /api/sessions`
- `GET /api/sessions/<session-id>`
- `GET /api/sessions/<session-id>/sensors/<sensor-key>?max_points=5000`
- `GET /api/sessions/<session-id>/sensors/<sensor-key>/csv`

The lightweight APK records all `SensorManager.TYPE_ALL` entries and arms one-shot trigger sensors correctly. Some event-driven sensors legitimately produce zero samples unless their physical trigger occurs during recording.

## Results

Each processed run contains:

- `trajectory.csv`: time, position, quaternion `(x,y,z,w)`, position standard deviations and tracking state.
- `trajectory.jsonl`: full pose, velocity, biases, pose covariance, diagnostics and active sensors.
- `optimized_trajectory.json`: accepted map-refinement poses; these are separate from the filter estimate.
- `marker_map.json`: reusable filter marker poses and covariance; optimized marker poses are a separate field.
- `detections.json`: ArUco corners, relative pose, reprojection error, initialization/update status and planar ambiguity.
- `diagnostics.json`, `optimization.json`, `summary.json`, `configuration.json` and `trajectory.png`.

The uncertainty plot displays approximately ±2 standard deviations per axis. It is not a guaranteed error bound. Optimized poses are not assigned the filter's covariance.

## Evaluate and reproduce

Ground truth CSV must contain `timestamp_s,x,y,z` in the same time and coordinate frame. Optional `qx,qy,qz,qw` enables orientation error. Use a surveyed or independently measured reference; do not reuse the estimated trajectory as ground truth.

```powershell
.\.venv\Scripts\python.exe -m slam.cli evaluate recordings\YOUR_RUN\processed\trajectory.csv ground_truth.csv
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

`--align` permits a rigid SE(3) alignment when frames differ; it does not fit a scale. Tests cover inertial propagation, Jacobians, MSCKF updates, covariance, gating, dropout, missing-gyro fallback, marker origin, map persistence, visual loop verification, transport, depth and synthetic replay. [VALIDATION.md](docs/VALIDATION.md) separates these software checks from pending hardware experiments.

The original assignment is included under `docs/Project (1).pdf`. Its prototype permits offline processing. A real phone dataset, surveyed experiments, report and demonstration video still need to be produced with the physical device.
