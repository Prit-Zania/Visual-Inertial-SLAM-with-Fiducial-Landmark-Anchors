$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$projectPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $projectPython)) {
    throw 'Run Setup-Python.ps1 once before starting the sensor API.'
}
& $projectPython -m slam.sensor_api --recordings recordings --host 127.0.0.1 --port 8080
