package org.oneplus.sensorsimple;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.hardware.ConsumerIrManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Base64;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Lightweight project recorder: all exposed sensors + camera + optional Wi-Fi stream. */
public final class MainActivity extends Activity implements SensorEventListener, SurfaceHolder.Callback, Camera.PreviewCallback {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private final ArrayBlockingQueue<JSONObject> records = new ArrayBlockingQueue<JSONObject>(2048);
    private final Map<Sensor, Integer> sensorKeys = new HashMap<Sensor, Integer>();
    private final TriggerEventListener triggerListener = new TriggerEventListener() {
        @Override public void onTrigger(TriggerEvent event) {
            emitSensor(event.sensor, event.timestamp, SensorManager.SENSOR_STATUS_ACCURACY_HIGH, event.values);
            if (recording) sensorManager.requestTriggerSensor(this, event.sensor);
        }
    };
    private SensorManager sensorManager;
    private Camera camera;
    private SurfaceView preview;
    private EditText hostField;
    private EditText portField;
    private EditText tokenField;
    private TextView status;
    private Button startButton;
    private Button stopButton;
    private volatile boolean recording;
    private volatile long lastFrameNs;
    private Thread writerThread;
    private File outputFile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 10, 16, 10);
        TextView title = new TextView(this);
        title.setText("OnePlus 12R Sensor + Camera Capture");
        title.setTextSize(21);
        root.addView(title);

        LinearLayout connection = new LinearLayout(this);
        hostField = new EditText(this);
        hostField.setHint("Laptop IP (optional)");
        hostField.setSingleLine(true);
        connection.addView(hostField, new LinearLayout.LayoutParams(0, -2, 2));
        portField = new EditText(this);
        portField.setHint("Port");
        portField.setText("8765");
        portField.setSingleLine(true);
        connection.addView(portField, new LinearLayout.LayoutParams(0, -2, 1));
        tokenField = new EditText(this);
        tokenField.setHint("Pairing token");
        tokenField.setSingleLine(true);
        connection.addView(tokenField, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(connection);

        LinearLayout controls = new LinearLayout(this);
        startButton = new Button(this);
        startButton.setText("Start");
        stopButton = new Button(this);
        stopButton.setText("Stop and save");
        stopButton.setEnabled(false);
        controls.addView(startButton);
        controls.addView(stopButton);
        root.addView(controls);

        status = new TextView(this);
        status.setText("Ready. Laptop IP may be blank for local recording.");
        root.addView(status);
        preview = new SurfaceView(this);
        preview.getHolder().addCallback(this);
        root.addView(preview, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { startCapture(); }
        });
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { stopCapture(); }
        });
    }

    private void startCapture() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 10);
            return;
        }
        if (!preview.getHolder().getSurface().isValid()) {
            setStatus("Camera surface is not ready yet.");
            return;
        }
        try {
            final String session = UUID.randomUUID().toString();
            File directory = new File(getExternalFilesDir(null), "sessions/" + session);
            if (!directory.mkdirs() && !directory.isDirectory()) throw new Exception("Cannot create session folder");
            outputFile = new File(directory, "capture.jsonl");
            recording = true;
            writerThread = new Thread(new WriterTask(hostField.getText().toString().trim(), Integer.parseInt(portField.getText().toString()), tokenField.getText().toString().trim()), "capture-writer");
            writerThread.start();

            JSONObject hello = new JSONObject();
            hello.put("kind", "hello");
            hello.put("protocol", "oneplus-msckf-v1");
            hello.put("session_id", session);
            hello.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            hello.put("android", Build.VERSION.RELEASE);
            hello.put("elapsed_realtime_ns", SystemClock.elapsedRealtimeNanos());
            ConsumerIrManager ir = (ConsumerIrManager)getSystemService(Context.CONSUMER_IR_SERVICE);
            hello.put("ir_emitter", ir != null && ir.hasIrEmitter());
            hello.put("ir_range_available", false);
            JSONArray inventory = new JSONArray();
            List<Sensor> sensors = sensorManager.getSensorList(Sensor.TYPE_ALL);
            sensorKeys.clear();
            int sensorKey = 0;
            for (Sensor sensor : sensors) {
                sensorKeys.put(sensor, ++sensorKey);
                JSONObject item = new JSONObject();
                item.put("key", sensorKey);
                item.put("type", sensor.getType());
                item.put("name", sensor.getName());
                item.put("vendor", sensor.getVendor());
                item.put("version", sensor.getVersion());
                item.put("string_type", sensor.getStringType());
                item.put("wake_up", sensor.isWakeUpSensor());
                item.put("reporting_mode", sensor.getReportingMode());
                item.put("min_delay_us", sensor.getMinDelay());
                item.put("max_delay_us", sensor.getMaxDelay());
                item.put("power_ma", sensor.getPower());
                item.put("resolution", sensor.getResolution());
                item.put("maximum_range", sensor.getMaximumRange());
                inventory.put(item);
            }
            hello.put("available_sensor_count", sensors.size());
            hello.put("sensors", inventory);
            enqueue(hello);
            for (Sensor sensor : sensors) {
                boolean registered;
                if (sensor.getReportingMode() == Sensor.REPORTING_MODE_ONE_SHOT) {
                    registered = sensorManager.requestTriggerSensor(triggerListener, sensor);
                } else {
                    int periodUs = (sensor.getType() == Sensor.TYPE_ACCELEROMETER || sensor.getType() == Sensor.TYPE_GYROSCOPE) ? 5000 :
                        ((sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD || sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) ? 20000 : 50000);
                    registered = sensorManager.registerListener(this, sensor, periodUs, 0);
                }
                enqueue(new JSONObject().put("kind", "sensor_registration")
                    .put("sensor_key", sensorKeys.get(sensor)).put("registered", registered)
                    .put("wake_up", sensor.isWakeUpSensor()).put("reporting_mode", sensor.getReportingMode()));
            }
            openCamera();
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            setStatus("Recording " + sensors.size() + " exposed sensors and camera. File: " + outputFile.getAbsolutePath());
        } catch (Exception error) {
            stopCapture();
            setStatus("Cannot start: " + error.getMessage());
        }
    }

    @SuppressWarnings("deprecation") private void openCamera() throws Exception {
        int selected = 0;
        int count = Camera.getNumberOfCameras();
        Camera.CameraInfo info = new Camera.CameraInfo();
        for (int index = 0; index < count; index++) {
            Camera.getCameraInfo(index, info);
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) { selected = index; break; }
        }
        camera = Camera.open(selected);
        Camera.Parameters parameters = camera.getParameters();
        Camera.Size chosen = parameters.getSupportedPreviewSizes().get(0);
        long best = Long.MAX_VALUE;
        for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
            long difference = Math.abs((long)size.width * size.height - 640L * 480L);
            if (difference < best) { best = difference; chosen = size; }
        }
        parameters.setPreviewSize(chosen.width, chosen.height);
        parameters.setPreviewFormat(ImageFormat.NV21);
        List<String> focusModes = parameters.getSupportedFocusModes();
        if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
        camera.setParameters(parameters);
        camera.setPreviewDisplay(preview.getHolder());
        camera.setPreviewCallback(this);
        camera.startPreview();
        JSONObject cameraInfo = new JSONObject();
        cameraInfo.put("kind", "camera_info");
        cameraInfo.put("camera_id", selected);
        cameraInfo.put("width", chosen.width);
        cameraInfo.put("height", chosen.height);
        cameraInfo.put("format", "NV21_to_JPEG");
        cameraInfo.put("laser_af_range", "not_exposed_by_standard_android_api");
        enqueue(cameraInfo);
    }

    private void stopCapture() {
        if (recording) {
            try { enqueue(new JSONObject().put("kind", "end")); }
            catch (Exception ignored) { }
        }
        recording = false;
        sensorManager.unregisterListener(this);
        for (Sensor sensor : sensorKeys.keySet()) sensorManager.cancelTriggerSensor(triggerListener, sensor);
        if (camera != null) {
            camera.setPreviewCallback(null);
            camera.stopPreview();
            camera.release();
            camera = null;
        }
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
        if (outputFile != null) setStatus("Saved: " + outputFile.getAbsolutePath());
    }

    private void enqueue(JSONObject object) {
        if (!records.offer(object)) setStatus("Recorder queue full; slow down phone movement.");
    }

    @Override public void onSensorChanged(SensorEvent event) {
        emitSensor(event.sensor, event.timestamp, event.accuracy, event.values);
    }

    private void emitSensor(Sensor sensor, long timestamp, int accuracy, float[] sampleValues) {
        if (!recording) return;
        try {
            JSONObject record = new JSONObject();
            record.put("kind", "sensor");
            record.put("sensor_type", sensor.getType());
            Integer sensorKey = sensorKeys.get(sensor);
            record.put("sensor_key", sensorKey == null ? 0 : sensorKey.intValue());
            record.put("sensor_name", sensor.getName());
            record.put("wake_up", sensor.isWakeUpSensor());
            record.put("timestamp_ns", timestamp);
            record.put("accuracy", accuracy);
            JSONArray values = new JSONArray();
            for (float value : sampleValues) values.put(value);
            record.put("values", values);
            enqueue(record);
        } catch (Exception error) { setStatus("Sensor error: " + error.getMessage()); }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @SuppressWarnings("deprecation") @Override public void onPreviewFrame(byte[] data, Camera source) {
        if (!recording) return;
        long now = SystemClock.elapsedRealtimeNanos();
        if (now - lastFrameNs < 200000000L) return;
        lastFrameNs = now;
        try {
            Camera.Size size = source.getParameters().getPreviewSize();
            YuvImage image = new YuvImage(data, ImageFormat.NV21, size.width, size.height, null);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            image.compressToJpeg(new android.graphics.Rect(0, 0, size.width, size.height), 72, bytes);
            JSONObject frame = new JSONObject();
            frame.put("kind", "frame");
            frame.put("timestamp_ns", now);
            frame.put("width", size.width);
            frame.put("height", size.height);
            frame.put("format", "jpeg");
            frame.put("image_b64", Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP));
            enqueue(frame);
        } catch (Exception error) { setStatus("Camera frame error: " + error.getMessage()); }
    }

    private void setStatus(final String text) {
        runOnUiThread(new Runnable() { @Override public void run() { status.setText(text); } });
    }

    @Override public void surfaceCreated(SurfaceHolder holder) { }
    @Override public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) { }
    @Override public void surfaceDestroyed(SurfaceHolder holder) { stopCapture(); }
    @Override protected void onPause() { stopCapture(); super.onPause(); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 10 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startCapture();
        else setStatus("Camera permission is required.");
    }

    private final class WriterTask implements Runnable {
        private final String host;
        private final int port;
        private final String token;
        WriterTask(String host, int port, String token) { this.host = host; this.port = port; this.token = token; }
        @Override public void run() {
            Socket socket = null;
            BufferedWriter network = null;
            BufferedWriter disk = null;
            try {
                disk = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile), UTF8), 262144);
                if (host.length() > 0) {
                    try {
                        socket = new Socket();
                        socket.connect(new InetSocketAddress(host, port), 4000);
                        network = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), UTF8));
                    } catch (Exception networkError) {
                        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
                        socket = null;
                        network = null;
                        setStatus("Laptop connection unavailable; local recording continues.");
                    }
                }
                boolean first = true;
                long sequence = 0;
                while (recording || !records.isEmpty()) {
                    JSONObject record = records.poll(200, TimeUnit.MILLISECONDS);
                    if (record == null) continue;
                    String line;
                    if (first) {
                        line = record.toString();
                        disk.write(line); disk.newLine(); disk.flush();
                        if (network != null) {
                            try {
                                JSONObject authenticatedHello = new JSONObject(line);
                                authenticatedHello.put("token", token);
                                network.write(authenticatedHello.toString()); network.newLine(); network.flush();
                                final BufferedReader feedback = new BufferedReader(new InputStreamReader(socket.getInputStream(), UTF8));
                                socket.setSoTimeout(8000);
                                String reply = feedback.readLine();
                                if (reply == null || !"ready".equals(new JSONObject(reply).optString("kind"))) throw new Exception("Pairing rejected");
                                socket.setSoTimeout(0);
                                new Thread(new Runnable() {
                                    @Override public void run() {
                                        try {
                                            String response;
                                            while ((response = feedback.readLine()) != null) {
                                                JSONObject report = new JSONObject(response);
                                                if ("markers".equals(report.optString("kind"))) {
                                                    setStatus("ArUco IDs: " + report.optJSONArray("ids") + " | frames: " + report.optInt("frames_saved") + " | IMU: " + (report.optBoolean("imu_recent") ? "OK" : "waiting"));
                                                }
                                            }
                                        } catch (Exception ignored) { }
                                    }
                                }, "receiver-feedback").start();
                            } catch (Exception pairingError) {
                                try { network.close(); } catch (Exception ignored) { }
                                try { socket.close(); } catch (Exception ignored) { }
                                network = null;
                                socket = null;
                                setStatus("Pairing failed; local recording continues. Check IP and token.");
                            }
                        }
                        first = false;
                        continue;
                    }
                    record.put("seq", ++sequence);
                    line = record.toString();
                    disk.write(line); disk.newLine();
                    if (network != null) {
                        try { network.write(line); network.newLine(); network.flush(); }
                        catch (Exception networkError) {
                            try { network.close(); } catch (Exception ignored) { }
                            try { if (socket != null) socket.close(); } catch (Exception ignored) { }
                            network = null;
                            socket = null;
                            setStatus("Wi-Fi stream stopped; local recording continues.");
                        }
                    }
                }
                disk.flush(); disk.close();
            } catch (final Exception error) {
                setStatus("Recording error: " + error.getMessage() + ". File: " + outputFile);
            } finally {
                try { if (disk != null) disk.close(); } catch (Exception ignored) { }
                try { if (network != null) network.close(); } catch (Exception ignored) { }
                try { if (socket != null) socket.close(); } catch (Exception ignored) { }
            }
        }
    }
}
