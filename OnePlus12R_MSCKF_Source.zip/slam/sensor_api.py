"""Read-only HTTP API and browser visualization for recorded phone sensors."""
from __future__ import annotations

import argparse
import csv
import io
import json
import math
from collections import Counter,defaultdict
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs,unquote,urlparse

ROOT=Path(__file__).resolve().parents[1]
WEB=Path(__file__).with_name('sensor_web.html')


def _json(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,json.JSONDecodeError):return default


def _sessions(root):
    result=[]
    if not root.exists():return result
    for folder in sorted((p for p in root.iterdir() if p.is_dir()),reverse=True):
        if not (folder/'events.jsonl').is_file():continue
        metadata=_json(folder/'metadata.json',{})
        capture=_json(folder/'capture_summary.json',{})
        result.append({'id':folder.name,'device':metadata.get('device','unknown'),
            'android':metadata.get('android'),'sensor_count':len(metadata.get('sensors',[])),
            'records':capture.get('records'),'reason':capture.get('reason')})
    return result


def _resolve(root,name):
    if not name or Path(name).name!=name:raise ValueError('Invalid session id')
    folder=(root/name).resolve()
    if folder.parent!=root.resolve() or not (folder/'events.jsonl').is_file():raise FileNotFoundError(name)
    return folder


def _records(folder):
    with (folder/'events.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            if line.strip():yield json.loads(line)


def session_summary(folder):
    metadata=_json(folder/'metadata.json',{})
    registrations={}
    stats=defaultdict(lambda:{'count':0,'first_ns':None,'last_ns':None,'dimensions':0,'accuracy':Counter()})
    frames=0
    for record in _records(folder):
        kind=record.get('kind')
        if kind=='sensor_registration':registrations[str(record.get('sensor_key'))]=bool(record.get('registered'))
        elif kind=='sensor':
            key=str(record.get('sensor_key'));item=stats[key];stamp=record.get('timestamp_ns')
            item['count']+=1;item['dimensions']=max(item['dimensions'],len(record.get('values',[])))
            item['accuracy'][str(record.get('accuracy'))]+=1
            if isinstance(stamp,int):
                item['first_ns']=stamp if item['first_ns'] is None else min(item['first_ns'],stamp)
                item['last_ns']=stamp if item['last_ns'] is None else max(item['last_ns'],stamp)
        elif kind=='frame':frames+=1
    inventory=[]
    for sensor in metadata.get('sensors',[]):
        key=str(sensor.get('key'));item=stats[key];duration=0.0
        if item['first_ns'] is not None and item['last_ns'] is not None:duration=max(0.0,(item['last_ns']-item['first_ns'])/1e9)
        rate=(item['count']-1)/duration if item['count']>1 and duration>0 else 0.0
        inventory.append({**sensor,'key':sensor.get('key'),'registered':registrations.get(key),
            'samples':item['count'],'duration_s':duration,'effective_rate_hz':rate,
            'dimensions':item['dimensions'],'accuracy_counts':dict(item['accuracy'])})
    return {'id':folder.name,'metadata':metadata,'capture':_json(folder/'capture_summary.json',{}),
        'frames':frames,'sensors':inventory}


def sensor_samples(folder,key,max_points=4000):
    rows=[r for r in _records(folder) if r.get('kind')=='sensor' and str(r.get('sensor_key'))==str(key)]
    if not rows:return {'sensor_key':key,'count':0,'returned':0,'samples':[]}
    stride=max(1,math.ceil(len(rows)/max(1,min(max_points,20000))))
    origin=rows[0]['timestamp_ns']
    samples=[{'time_s':(r['timestamp_ns']-origin)/1e9,'timestamp_ns':r['timestamp_ns'],
        'values':r.get('values',[]),'accuracy':r.get('accuracy'),'seq':r.get('seq')} for r in rows[::stride]]
    return {'sensor_key':key,'name':rows[0].get('sensor_name'),'wake_up':rows[0].get('wake_up'),
        'count':len(rows),'returned':len(samples),'stride':stride,'samples':samples}


class ApiHandler(BaseHTTPRequestHandler):
    server_version='OnePlusSensorAPI/1.0'
    def _send(self,status,body,content_type='application/json; charset=utf-8'):
        if not isinstance(body,(bytes,bytearray)):body=body.encode('utf-8')
        self.send_response(status);self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store')
        self.send_header('Access-Control-Allow-Origin','*');self.end_headers();self.wfile.write(body)
    def _json_response(self,value,status=200):self._send(status,json.dumps(value,allow_nan=False))
    def do_GET(self):
        try:
            parsed=urlparse(self.path);parts=[unquote(p) for p in parsed.path.split('/') if p]
            if not parts:
                self._send(200,WEB.read_bytes(),'text/html; charset=utf-8');return
            if parts==['api','sessions']:
                self._json_response({'sessions':_sessions(self.server.recordings_root)});return
            if len(parts)>=3 and parts[:2]==['api','sessions']:
                folder=_resolve(self.server.recordings_root,parts[2])
                if len(parts)==3:
                    self._json_response(session_summary(folder));return
                if len(parts)==5 and parts[3]=='sensors':
                    limit=int(parse_qs(parsed.query).get('max_points',['4000'])[0])
                    self._json_response(sensor_samples(folder,parts[4],limit));return
                if len(parts)==6 and parts[3]=='sensors' and parts[5]=='csv':
                    data=sensor_samples(folder,parts[4],20000);stream=io.StringIO();writer=csv.writer(stream)
                    dimensions=max((len(s['values']) for s in data['samples']),default=0)
                    writer.writerow(['timestamp_ns','time_s','accuracy',*['value_'+str(i) for i in range(dimensions)]])
                    for sample in data['samples']:writer.writerow([sample['timestamp_ns'],sample['time_s'],sample['accuracy'],*sample['values']])
                    self._send(200,stream.getvalue(),'text/csv; charset=utf-8');return
            self._json_response({'error':'not found'},404)
        except FileNotFoundError:self._json_response({'error':'session not found'},404)
        except (ValueError,KeyError,json.JSONDecodeError) as exc:self._json_response({'error':str(exc)},400)
        except Exception as exc:self._json_response({'error':type(exc).__name__+': '+str(exc)},500)
    def log_message(self,format,*args):print('[sensor-api]',format%args)


def serve(recordings='recordings',host='127.0.0.1',port=8080):
    root=Path(recordings).resolve();root.mkdir(parents=True,exist_ok=True)
    server=ThreadingHTTPServer((host,port),ApiHandler);server.recordings_root=root
    print(f'Sensor API and visualization: http://{host}:{port}')
    print('Recordings: '+str(root))
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--recordings',default=str(ROOT/'recordings'))
    parser.add_argument('--host',default='127.0.0.1');parser.add_argument('--port',type=int,default=8080)
    args=parser.parse_args();serve(args.recordings,args.host,args.port)


if __name__=='__main__':main()
